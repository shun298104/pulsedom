import { Node, NodeId, EctopicOptions, BurstOptions } from '../../types/NodeTypes';

export const mkNode = (
  id: NodeId,
  bpm: number,
  refMs: number,
  autoFire: boolean,
  x: number,
  y: number,
  z: number,
  ectopicOptions?: EctopicOptions,
  burstOptions?: BurstOptions
): Node => ({
  id,
  bpm,
  primaryRefractoryMs: refMs,
  lastFiredAt: -1000,
  autoFire,
  x,
  y,
  z,
  ectopicOptions,
  burstOptions,

  getRefractoryMs(now) {
    return this.adaptiveRefractoryMs ?? this.primaryRefractoryMs;
  },

  shouldAutoFire(now, dynamicHR = 80) {
    if (this.autoFire) {
      const interval = 60000 / this.bpm;
      return now - this.lastFiredAt >= interval;
    }

    if (this.ectopicOptions?.enabled) {
      const interval = this.burstOptions?.currentCount > 0
        ? this.burstOptions.intervalMs
        : 60000 / (dynamicHR * (this.ectopicOptions.bpmFactor ?? 1.3));
      const canFire = now - this.lastFiredAt >= interval;

      if (this.burstOptions?.currentCount > 0 && canFire) {
        this.burstOptions.currentCount--;
        return true;
      }

      if (canFire && Math.random() <= this.ectopicOptions.probability) {
        if (this.burstOptions) {
          this.burstOptions.currentCount = this.burstOptions.maxCount - 1;
        }
        return true;
      }
    }

    return false;
  },
});
