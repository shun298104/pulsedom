// src/types/SimOptions.ts
import { NodeId } from '../types/NodeTypes';
import { graphControlRules } from '../rules/graphControlRules';

export type RawSimOptions = {
  statuses: string[];
  hr: number;
  rr: number;
  spo2: number;

  sinus: {
    rate: number;
    options?: ('PAC1' | 'PAC3' | 'SSS3')[];
    pac?: {
      level: number;
    };
  };

  junction: {
    rate: number;
    options?: ('PAC1' | 'PAC3' | 'SSS3')[];
    conductionRate?: '1:1' | '2:1' | '3:1' | '4:1' | '5:1';
  };

  ventricle: {
    rate: number;
    options?: ('PVC1' | 'PVC2' | 'PVC3' | 'PVC4a' | 'PVC4b' | 'PVC5')[];
  };

  pacing?: {
    mode: 'OFF' | 'AOO' | 'VOO' | 'VVI' | 'DDD';
    lowerRateLimit: number;
    upperRateLimit: number;
    avDelay: number;
  };

};

export class SimOptions {
  constructor(private rawData: RawSimOptions) {}

  getRaw(): RawSimOptions {
    return this.rawData;
  }

  get hr() { return this.rawData.hr; }
  set hr(val: number) { this.rawData.hr = val; }
  get rr() { return this.rawData.rr; }
  set rr(val: number) { this.rawData.rr = val; }
  get spo2(): number { return this.rawData.spo2; }
  set spo2(val: number) { this.rawData.spo2 = val; }

  get sinus() { return this.rawData.sinus; }
  get sinusRate() { return this.rawData.sinus.rate; }
  set sinusRate(val: number) { this.rawData.sinus.rate = val; }

  get junction() { return this.rawData.junction; }
  get junctionRate() { return this.rawData.junction.rate; }
  set junctionRate(val: number) { this.rawData.junction.rate = val; }
  get conductionRate() { return this.rawData.junction.conductionRate; }
  set conductionRate(val: RawSimOptions['junction']['conductionRate']) {
    this.rawData.junction.conductionRate = val;
  }

  get ventricle() { return this.rawData.ventricle; }
  get ventricleRate() { return this.rawData.ventricle.rate; }
  set ventricleRate(val: number) { this.rawData.ventricle.rate = val; }

  get pacing() { return this.rawData.pacing; }

  getRate(nodeId: NodeId): number {
    switch (nodeId) {
      case 'SA': return this.rawData.sinus.rate;
      case 'NH': return this.rawData.junction.rate;
      case 'V': return this.rawData.ventricle.rate;
      default: return 0;
    }
  }

  getNodeAutofire(nodeId: NodeId): boolean {
    switch (nodeId) {
      case 'SA': return !this.statuses.includes("stop");
      case 'NH': return true;
      case 'V': return true;
      default: return false;
    }
  }

  isPathBlocked(pathId: string): boolean {
    if (pathId === 'N->NH') return this.statuses.includes("CAV block");
    return false;
  }

  getPathDelay(pathId: string): number {
    return 0;
  }

  get statuses(): string[] {
    return this.rawData.statuses ?? [];
  }
  set statuses(val: string[]) {
    this.rawData.statuses = val;
  }

  setStatus(newStatus: string) {
    const rule = graphControlRules.find(r => r.id === newStatus);
    const group = rule?.exclusiveGroup ?? rule?.group;
    const filtered = this.statuses.filter(id => {
      const r = graphControlRules.find(r => r.id === id);
      return (r?.exclusiveGroup ?? r?.group) !== group;
    });
    this.statuses = [...filtered, newStatus];
  }

  applyGraphRules(graph: {
    setNodeAutofire: (nodeId: string, enabled: boolean) => void;
    setPathBlocked?: (from: string, to: string, blocked: boolean) => void;
  }) {
    const isStopped = this.statuses.includes("stop");
    const isBlocked = this.statuses.includes("CAV block");

    graph.setNodeAutofire('SA', !isStopped);
    graph.setPathBlocked?.('N', 'NH', isBlocked);
  }
}

export function createDefaultSimOptions(): SimOptions {
  return new SimOptions({
    statuses: ["AtrialNormal"],
    hr: 80,
    rr: 750,
    spo2: 98,
    sinus: {
      rate: 80,
      options: [],
      pac: { level: 0 },
    },
    junction: {
      rate: 40,
      options: [],
      conductionRate: '1:1',
    },
    ventricle: {
      rate: 30,
      options: [],
    },
    pacing: {
      mode: 'OFF',
      lowerRateLimit: 50,
      upperRateLimit: 120,
      avDelay: 120,
    },
  });
}

export default createDefaultSimOptions;
