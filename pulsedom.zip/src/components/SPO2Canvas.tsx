// src/components/SpO2Canvas.tsx
import React, { useEffect, useRef, useState } from 'react';
import { PX_SCALE } from '../constants/constants';

interface SpO2CanvasProps {
  bufferRef: React.MutableRefObject<{ getArray: () => number[]; size: () => number }>;
}

const SpO2Canvas: React.FC<SpO2CanvasProps> = ({ bufferRef }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new ResizeObserver(entries => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setSize({ width, height });
      }
    });

    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || size.width === 0 || size.height === 0) return;

    const draw = () => {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;
      const DELAY_MS = 100;
      const STEP_MS = 5;
      const delaySamples = Math.floor(DELAY_MS / STEP_MS); // ← 20個遅らせる！
      
    
      const baseline = size.height * 0.5;
      const gain = PX_SCALE.pxPerMv * 0.5; // SpO2は少し控えめなスケーリング

      ctx.clearRect(0, 0, size.width, size.height);
      ctx.beginPath();
      ctx.strokeStyle = 'cyan';
      ctx.lineWidth = 2;

      // 時間軸に応じたx座標
      const visibleSec = size.width / PX_SCALE.pxPerSec;
      const visibleSamples = Math.floor(visibleSec * 1000 / 5); // ←STEP_MS = 5
      const rawBuffer = bufferRef.current.pulse.getArray();
      const buffer = rawBuffer.slice(0, rawBuffer.length - delaySamples);
      const wave = buffer.slice(-visibleSamples);

      for (let i = 0; i < wave.length; i++) {
        const timeOffsetSec = (wave.length - i) * 5 / 1000;
        const x = size.width - timeOffsetSec * PX_SCALE.pxPerSec;
        const y = baseline - wave[i] * gain;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }

      ctx.stroke();
      requestAnimationFrame(draw);
    };

    requestAnimationFrame(draw);
  }, [size]);

  return (
    <div ref={containerRef} className="w-full h-[100px] sm:h-[120px] md:h-[140px] lg:h-[160px]">
      <canvas
        ref={canvasRef}
        width={size.width}
        height={size.height}
        className="bg-black rounded-2xl"
      />
    </div>
  );
};

export default SpO2Canvas;
