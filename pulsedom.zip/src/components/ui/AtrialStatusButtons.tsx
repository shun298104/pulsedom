import { graphControlRules } from "../../rules/graphControlRules";

export function AtrialStatusButtons({
  statuses,
  setStatus,
}: {
  statuses: string[];
  setStatus: (s: string) => void;
}) {
  const current = statuses.find((s) => {
    const rule = graphControlRules.find(r => r.id === s);
    return (rule?.exclusiveGroup ?? rule?.group) === "AtrialStatus";
  }) ?? "AtrialNormal";

  const options = ["Af", "AFL", "stop", "AtrialNormal"];

  return (
    <div className="flex gap-2 text-xs">
      {options.map((s) => (
        <button
          key={s}
          className={`px-2 py-1 rounded border ${
            current === s ? "bg-zinc-300" : "bg-white"
          }`}
          onClick={() => setStatus(s)}
        >
          {s}
        </button>
      ))}
    </div>
  );
}
