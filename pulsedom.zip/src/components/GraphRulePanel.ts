// src/components/GraphRulePanel.tsx
import React from "react";
import { Accordion, AccordionItem } from "./ui/accordion";
import { Switch } from "./ui/switch";
import { graphControlRules } from "../rules/graphControlRules";
import type { SimOptions } from "../types/SimOptions";

type Props = {
  sim: SimOptions;                     // ← 状態保持オブジェクト
  onChange: (next: string[]) => void;  // ← statuses[] が変わったとき呼ぶ
};

export default function GraphRulePanel({ sim, onChange }: Props) {
  // グループ別にまとめる
  const grouped = graphControlRules.reduce<Record<string, typeof graphControlRules>>(
    (acc, rule) => {
      (acc[rule.group ?? "Other"] ??= []).push(rule);
      return acc;
    },
    {}
  );

  const toggleStatus = (id: string, enabled: boolean) => {
    const next = enabled
      ? [...sim.statuses, id]
      : sim.statuses.filter(s => s !== id);
    onChange(next);
  };

  return (
    <Accordion type="multiple" className="w-full">
      {Object.entries(grouped).map(([group, rules]) => (
        <AccordionItem key={group} value={group} title={group}>
          <div className="flex flex-col gap-2 px-4 py-2">
            {rules.map(rule => {
              const checked = sim.statuses.includes(rule.id);
              return (
                <label key={rule.id} className="flex items-center gap-2">
                  <Switch
                    checked={checked}
                    onCheckedChange={v => toggleStatus(rule.id, v)}
                  />
                  <span className="text-sm font-medium">{rule.label}</span>
                </label>
              );
            })}
          </div>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
