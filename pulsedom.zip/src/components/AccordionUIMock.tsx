import { SimOptions } from "../types/SimOptions";
import WaveformSlider from "./ui/WaveformSlider";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";
import { graphControlRules } from "../rules/graphControlRules";
import { AtrialStatusButtons } from "./ui/AtrialStatusButtons";

interface AccordionUIMockProps {
  simOptions: SimOptions;
  onSimOptionsChange: (next: SimOptions) => void;
  isBeepOn: boolean;
  onToggleBeep: () => void;
}

export function AccordionUIMock({
  simOptions,
  onSimOptionsChange,
  isBeepOn,
  onToggleBeep,
}: AccordionUIMockProps) {
  // ------- 状態更新関数（SimOptions クラス対応） --------
  const updateRate = (
    node: "sinus" | "junction" | "ventricle",
    value: number
  ) => {
    const next = new SimOptions(simOptions.getRaw());
    switch (node) {
      case "sinus":
        next.sinusRate = value;
        break;
      case "junction":
        next.junctionRate = value;
        break;
      case "ventricle":
        next.ventricleRate = value;
        break;
    }
    onSimOptionsChange(next);
  };

  const updateStatuses = (id: string, enabled: boolean) => {
    const current = simOptions.statuses;
    const next = enabled
      ? Array.from(new Set([...current, id]))
      : current.filter((r) => r !== id);
    const updated = new SimOptions(simOptions.getRaw());
    updated.statuses = next;
    onSimOptionsChange(updated);
  };

  const updatePAC = (value: number) => {
    const raw = simOptions.getRaw();
    const nextRaw = {
      ...raw,
      pac: {
        ...(raw.pac ?? {}),
        level: value,
      },
    };
    onSimOptionsChange(new SimOptions(nextRaw));
  };

  const toggleStatus = (status: Status) => {
    const updated = new SimOptions(simOptions.getRaw());
    updated.statuses = status === "AtrialNormal" ? [] : [status];
    onSimOptionsChange(updated);
  };

  const groupedRules = graphControlRules.reduce((acc, rule) => {
    if (!acc[rule.group]) acc[rule.group] = [];
    acc[rule.group].push(rule);
    return acc;
  }, {} as Record<string, typeof graphControlRules>);

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center gap-2 px-1">
        <button
          className={`text-xs font-medium tracking-wide px-3 py-1 rounded border border-zinc-400 transition ${isBeepOn
            ? "bg-zinc-300 text-green-700"
            : "hover:bg-zinc-200"
            }`}
          onClick={onToggleBeep}
        >
          {isBeepOn ? "🔔 SYNC BEEP ON" : "🔕 SYNC BEEP"}
        </button>
      </div>

      <WaveformSlider
        label="SpO₂ (%)"
        value={simOptions.spo2}
        min={50}
        max={100}
        step={1}
        digits={0}
        unit="%"
        onChange={(v) => {
          const next = new SimOptions(simOptions.getRaw());
          next.spo2 = v;
          onSimOptionsChange(next);
        }}
      />

      <Accordion type="multiple" className="w-full space-y-2">
        <AccordionItem value="sinus">
          <AccordionTrigger>Sinus Node</AccordionTrigger>
          <AccordionContent className="space-y-2 text-sm">
            <WaveformSlider
              label="Sinus Rate (bpm)"
              value={simOptions.sinusRate}
              min={0}
              max={200}
              step={1}
              digits={0}
              unit="bpm"
              onChange={(v) => updateRate("sinus", v)}
            />

            <AtrialStatusButtons
              statuses={simOptions.statuses}
              setStatus={(s) => {
                const next = new SimOptions(simOptions.getRaw());
                next.setStatus(s); // 排他制御込み
                onSimOptionsChange(next);
              }}
            />

            <WaveformSlider
              label="PAC頻度"
              value={simOptions.getRaw().pac?.level ?? 0}
              min={0}
              max={10}
              step={1}
              digits={0}
              unit=""
              onChange={(v) => updatePAC(v)}
            />

            <div className="text-xs text-gray-500">
              {(() => {
                const level = simOptions.getRaw().pac?.level ?? 0;
                return level === 0
                  ? "PACなし"
                  : level <= 3
                    ? "まれにPAC"
                    : level <= 6
                      ? "連発PAC"
                      : level < 10
                        ? "高頻度PAC"
                        : "MAT（多源性心房頻拍）";
              })()}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="junction">
          <AccordionTrigger>Junction Node</AccordionTrigger>
          <AccordionContent className="space-y-1">
            <WaveformSlider
              label="Junction Rate (bpm)"
              value={simOptions.junctionRate}
              min={0}
              max={200}
              step={1}
              digits={0}
              unit="bpm"
              onChange={(v) => updateRate("junction", v)}
            />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="ventricle">
          <AccordionTrigger>Ventricle Node</AccordionTrigger>
          <AccordionContent className="space-y-1">
            <WaveformSlider
              label="Ventricle Rate (bpm)"
              value={simOptions.ventricleRate}
              min={0}
              max={200}
              step={1}
              digits={0}
              unit="bpm"
              onChange={(v) => updateRate("ventricle", v)}
            />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="graphControl">
          <AccordionTrigger>💡 Graph Control</AccordionTrigger>
          <AccordionContent className="space-y-2 text-sm">
            {Object.entries(groupedRules).map(
              ([groupName, rules]) => (
                <div key={groupName}>
                  <h4 className="text-xs font-semibold text-zinc-500 mb-1">
                    {groupName}
                  </h4>
                  {rules.map((rule) => (
                    <div
                      key={rule.id}
                      className="flex items-center gap-2 pl-2"
                    >
                      <input
                        type="checkbox"
                        id={rule.id}
                        checked={simOptions.statuses.includes(rule.id)}
                        onChange={(e) =>
                          updateStatuses(
                            rule.id,
                            e.target.checked
                          )
                        }
                        className="w-4 h-4"
                      />
                      <label
                        htmlFor={rule.id}
                        className="text-xs"
                      >
                        {rule.label}
                      </label>
                    </div>
                  ))}
                </div>
              )
            )}
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
