//src/constants/version.ts
export const PULSEDOM_VERSION = 'v0.9.2';
