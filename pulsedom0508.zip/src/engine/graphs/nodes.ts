import { mkNode } from './mkNodes';
import { Node } from '../../types/NodeTypes';

export const defaultNodes: Node[] = [
  mkNode('SA',  80, 200, true,   -1.5, -1.0, -1.5, false),
  mkNode('CT',  0,  200, false,  -1.0, -0.5, -1.0, false),
  mkNode('A',   0,  200, false,  -0.5, -0.7, -1.8, false),
  mkNode('LA',  0,  15,  false,  +0.8, -0.3, -0.5, false),
  mkNode('AN',  0,  300, false,  0.0,   0.0,  0.0, false),
  mkNode('N',   0,  300, false,  0.0,  +0.5,  0.0, false),
  mkNode('NH',  40, 300, true,   0.0,  +1.0,  0.0, false),
  mkNode('His', 0,  300, false,  0.0,  +1.5, +0.2, false),
  mkNode('V',   30, 300, true,   0.0,  +3.0, +0.5, false),

  // 💫 Atrial extras
  mkNode('IA',   0, 50, false,  +0.2, -0.2, -0.5, false),
  mkNode('PV1',  0, 15,  true,  +1.0, -0.6, -0.5, false),
  mkNode('PV2',  0, 15,  false,  +1.2, -0.2, -0.4, false),
  mkNode('CTI2', 0, 50, false,  -2.0,  0.0,  0.0, false),

  // QRS waveform minimal test nodes（開発用、一時利用）

  mkNode('LBB', 120, 250, false, -0.3, 0.4, 0.0, false),
  mkNode('RBB', 120, 250, false, 0.3, 0.4, 0.0, false),
  mkNode('V_sep', 0, 300, false, 0.3,  0.0,  0.0, false),
  mkNode('LV_main', 0, 300, false, 1.5, 3.0, 1.5, false),
  mkNode('RV', 0, 300, false, -2.0, 0.5, -0.2, false),
  mkNode('RV_auto', 30, 300, false, -2.0, 0.5, -0.2, false),
];
