//src/engine/graphs/mkNodes.ts
import { Node, NodeId } from '../../types/NodeTypes';

export const mkNode = (
  id: NodeId,
  bpm: number,
  refMs: number,
  autoFire: boolean,
  x: number,
  y: number,
  z: number,
  forceFiring : boolean,
): Node => ({
  id,
  bpm,
  primaryRefractoryMs: refMs,
  lastFiredAt: -1000,
  autoFire,
  x,
  y,
  z,
  forceFiring,

  getRefractoryMs(now) {
    return this.adaptiveRefractoryMs ?? this.primaryRefractoryMs;
  },

  shouldAutoFire(now) {
    if (this.autoFire) {
      const interval = 60000 / this.bpm;
      return now - this.lastFiredAt >= interval;
    }
    if (this.forceFiring){
      if(now - this.lastFiredAt >= this.getRefractoryMs(now)){
          console.log(this.id, 'forceFiring');
          this.forceFiring = false;
          return true;
      }
    }

    return false;
  },
});
